#!/usr/bin/python
# -*- coding: utf-8 -*-

from optparse import OptionParser
import os, re

parser = OptionParser()
parser.add_option("-x", dest="testsfile",
                       default="/home/moose/workspace/LittlePraktomat/src/Tests.txt", type="string",
                       help="The path to the Tests.txt file")
parser.add_option("-s", dest="executable",
                       default="/home/moose/workspace/LittlePraktomat/bin/Shell", type="string",
                       help="The path to the Tests.txt file")
parser.add_option("-i", dest="inputfile",
                       default="input.txt", type="string",
                       help="The path to the file with the input")
parser.add_option("-o", dest="outputfile",
                       default="output.txt", type="string",
                       help="The path to the file with the expected output")
parser.add_option("-t", dest="temporary",
                       default="/home/moose/tmp/", type="string",
                       help="Here does it store the temporary files.")
parser.add_option("-p", dest="inputprefix",
                       default="praktomat> ", type="string",
                       help="The prefix for input.")
parser.add_option("-v", "--verbose",
                  action="store_true", dest="verbose", default=False,
                  help="Show more information.")
(options, args) = parser.parse_args()

x = open(options.testsfile, 'r')
i = open(options.temporary + options.inputfile, 'w')
o = open(options.temporary + options.outputfile, 'w')

#noPrefix = True
for line in x:
	if options.inputprefix in line:
		inputline = line[len(options.inputprefix):]
		i.write(inputline)
		"""if noPrefix:
			noPrefix = False
		else:
			o.write(options.inputprefix)"""
	else:
		o.write(options.inputprefix + line)
		#noPrefix = True

x.close()
i.close()
o.close()


call1 = "java -classpath " \
	+ os.path.dirname(options.executable) + " " \
	+ os.path.basename(options.executable) \
	+ " < " \
	+ options.temporary + options.inputfile  \
	+ " > " + options.temporary \
	+ "createdOutput.txt"
print call1
os.system(call1)

f = open(options.temporary + "createdOutput.txt", 'r')
n = open(options.temporary + "createdOutputNormalized.txt", "w")
for line in f:
	line = re.sub("(" + options.inputprefix + ")+", options.inputprefix, line)
	if options.inputprefix not in line:
		n.write(options.inputprefix + line)
	else:
		n.write(line)

n.write("\n")

f.close()
n.close()

#+ options.temporary + options.inputfile  + " "\
call2 = "cat " \
	+ options.temporary + options.outputfile \
	+ " > " \
	+ options.temporary + "compareTo.txt"
print call2
os.system(call2)

# sdiff, colordiff, diff, meld
# sdiff /home/moose/tmp/createdOutputNormalized.txt /home/moose/tmp/compareTo.txt
