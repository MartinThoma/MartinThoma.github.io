/**
 * The class {@code Position} represents a position on the field.
 * @author Martin Thoma
 *
 */
public class Position {
	/** The format of a position as a String */
	public static final String REGEX_BOARDLIKE_FORMAT = "[A-Z]{1}[0-9]{1,2}";
	
	/** error message: move position */
	public static final String ERR_MOVE_POS_FORMAT = "A position has to be a character and "
		+ "then a number.";
	
	/** The x-coordinate in the Cartesian coordinate system */
	public final int x;
	
	/** The y-coordinate in the Cartesian coordinate system */
	public final int y;
	
	/**
	 * Constructor for the class Position.
	 * It stores the position in decimal out of a String like "A10" or "D9".
	 * @param position the String with the position
	 */
	public Position(String position) {
		if (!position.matches(REGEX_BOARDLIKE_FORMAT)) {
			throw new IllegalArgumentException(ERR_MOVE_POS_FORMAT);
		}

		x = (position.charAt(0) - 65);
		y = Integer.parseInt(position.substring(1)) - 1;
	}
	
	/**
	 * Constructor for the class Position.
	 * It stores the position directly in the Cartesian coordinate system. 
	 * @param x the x-coordinate in the Cartesian coordinate system
	 * @param y the y-coordinate in the Cartesian coordinate system
	 */
	public Position(int x, int y) {
		this.x = x;
		this.y = y;
	}

	/**
	 * Return a String representation of the object.
	 * Convert coordinates from Cartesian to board-like (e.g. (0 | 0) to A1 )
	 * @return String
	 */
	@Override
	public String toString() {
		String result;
		result = new Character((char) (65 + x)).toString();
		result += (y + 1);
		return result;
	}
}