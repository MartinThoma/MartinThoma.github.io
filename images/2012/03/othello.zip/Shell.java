import java.util.List;

/**
 * The class {@code Shell} implements a simple shell to test the functionalities of the
 * Othello game, to pass the information to Othello and to print the information in
 * Othello in a human-readable format.
 * @author Martin Thoma
 */
public class Shell {

	/** the prompt of this shell */
	private static final String PROMPT = "othello> ";

	/** command to terminate the shell */
	private static final String CMD_QUIT = "quit";

	/** command to create a new game */
	private static final String CMD_NEW_GAME = "newGame";

	/** command to move */
	private static final String CMD_MOVE = "move";

	/** command to print the current situation */
	private static final String CMD_PRINT = "print";

	/** command to abort */
	private static final String CMD_ABORT = "abort";

	/** command to show all possible moves of the current player */
	private static final String CMD_POSSIBLE_MOVES = "possibleMoves";

	/** command to add a hole to the board */
	private static final String CMD_HOLE = "hole";

	/** a regular expression which matches exactly all non-negative and even numbers */
	private static final String REGEX_POS_EVEN_NR = "^[0-9]*[02468]$";

	/**
	 * Private constructor. This is a Utility class that should not be
	 * instantiated.
	 */
	private Shell() {
	}

	/**
	 * Print the message which appears when the game ends.
	 * @param othello the Othello-Object whose result you want to get
	 */
	private static void printGameEndString(Othello othello) {
		String gameEndString;
		int[] result = othello.getResult();

		if (result[0] - result[1] == 0) {
			gameEndString = "Game has ended in a draw.";
		} else {
			Field winner = ((result[0] - result[1]) > 0) ? Field.WHITE : Field.BLACK;
			int winnerPoints = result[(winner == Field.WHITE) ? 0 : 1];
			int loserPoints = result[(winner == Field.WHITE) ? 1 : 0];
			gameEndString = "Game Over! "
				+ winner
				+ " has won (" + winnerPoints + ":" + loserPoints + ")!";
		}

		println(gameEndString);
	}

	// 	the command 'newGame <width> <height> [<situation>]'
	private static Othello newGameCommand(String[] tokens, Othello othello) {
		if (othello.isRunning()) {
			error("There is already an active game.");
		} else if (!(tokens.length == 3 || tokens.length == 4)) {
			error("The command is: newGame <width> <height> [<situation>]");
		} else if (!tokens[1].matches(REGEX_POS_EVEN_NR)) {
			error("The width has to be a positive, even number for the command newGame.");
		} else if (!tokens[2].matches(REGEX_POS_EVEN_NR)) {
			error("The height has to be a positive, even number for the command newGame.");
		} else {
			int width = Integer.parseInt(tokens[1]);
			int height = Integer.parseInt(tokens[2]);

			if (!Board.checkBoardSize(width, height)) {
				error(Board.ERR_INVALID_BOARD_SIZE);
				return othello;
			} else if (tokens.length == 3) {
				othello = new Othello(width, height);
			} else if (tokens.length == 4) {
				if (!Board.isSituationStringValid(width, height, tokens[3])) {
					error("The newgame situation parameter did not have the correct format.");
					return othello;
				} else {
					othello = new Othello(width, height, tokens[3]);
				}
			}

			if (!othello.isRunning()) {
				printGameEndString(othello);
			} else if (othello.getCurrentPlayer() == Field.WHITE) {
				Field lastPlayer = othello.getWaitingPlayer();
				println(lastPlayer + " passes.");
			}

		}

		return othello;
	}

	// the command 'move <position>'
	private static void moveCommand(String[] tokens, Othello othello) {
		if (tokens.length != 2) {
			error("You have to provide a position: move <position>.");
		} else if (!tokens[1].matches(Position.REGEX_BOARDLIKE_FORMAT)) {
			error(Position.ERR_MOVE_POS_FORMAT);
		} else if (!othello.isRunning()) {
			error(Othello.ERR_NO_ACTIVE_GAME);
		} else {
			int returnCode;
			Position position = new Position(tokens[1]);

			if (!othello.board.isPositionOnBoard(position)) {
				error(Othello.ERR_OFFBOARD_MOVE);
			} else {
				returnCode = othello.move(position);
				if (returnCode == -1) {
					// I've not used error() because of the tests.
					println("Move not possible.");
				} else if (returnCode == 1) {
					Field lastPlayer;
					lastPlayer = othello.getWaitingPlayer();
					println(lastPlayer + " passes.");
				} else if (returnCode == 2) {
					printGameEndString(othello);
				}
			}
		}
	}

	// the command 'hole <rectangle>'
	private static void holeCommand(String[] tokens, Othello othello) {
		if (tokens.length != 2) {
			error("The command is: 'hole <rectangle, seperated by ':'>'");
		} else if (!othello.isRunning()) {
		    // I forgot this...
		    error("No active game");
		} else if (tokens[1].indexOf(":") == -1) {
			error("The rectanble parameter did not have the correct format. "
					+ "The fields of the rectangle have to be seperated by ':'.");
		} else if (tokens[1].indexOf(":") != tokens[1].lastIndexOf(":")) {
			error(Othello.ERR_NO_VALID_RECTANGLE);
		} else if (othello.wasMoveSubmitted()) {
			error(Othello.ERR_PLAYER_MOVED);
		} else {
			String[] vertices = tokens[1].split(":");

			if (!vertices[0].matches(Position.REGEX_BOARDLIKE_FORMAT)
					|| !vertices[0].matches(Position.REGEX_BOARDLIKE_FORMAT)) {
				error(Position.ERR_MOVE_POS_FORMAT);
			} else {
				Position[] rectangle = {new Position(vertices[0]), new Position(vertices[1])};

				if (!othello.isValidRectangle(rectangle)) {
					error(Othello.ERR_NO_VALID_RECTANGLE);
				} else if (othello.isColorInRectangle(rectangle)) {
					error(Othello.ERR_COLOR_IN_RECTANGLE);
				} else {
					Field player = othello.getCurrentPlayer();

					othello.makeHole(rectangle);
					if (othello.getCurrentPlayer() != player) {
						println(player + " passes.");
					}
				}
			}
		}
	}

	// the command 'possibleMoves'
	private static void possibleMovesCommand(String[] tokens, Othello othello) {
		if (tokens.length != 1) {
			error("The command is: 'possibleMoves'.");
		} else if (!othello.isRunning()) {
			error(Othello.ERR_NO_ACTIVE_GAME);
		} else {
			List<Position> possibleMoves = othello.getPossibleMoves(othello.getCurrentPlayer());
			System.out.print("Possible moves: ");
			println(possibleMoves.toString().replace(", ", ",").replace("[", "").replace("]", ""));
		}
	}

	// The command 'print'
	private static void printCommand(String[] tokens, Othello othello) {
		if (tokens.length != 1) {
			error("The command is: 'print'.");
		} else if (!othello.isRunning()) {
			error(Othello.ERR_NO_ACTIVE_GAME);
		} else {
			println(othello.board.niceRepresentation());
			println("turn: " + othello.getCurrentPlayer());
		}
	}

	// The command 'abort'
	private static void abortCommand(String[] tokens, Othello othello) {
		if (tokens.length != 1) {
			error("The command is: 'abort'.");
		} else if (!othello.isRunning()) {
			error(Othello.ERR_NO_ACTIVE_GAME);
		} else {
			othello.abortGame();
			printGameEndString(othello);
		}
	}

	/**
	 * realizes the shell
	 * @param args command line arguments - not used here!
	 */
	public static void main(String[] args) {
		boolean quit = false;
		Othello othello = new Othello(8, 8);
		othello.setFinished();

		while (!quit) {
			String input = Terminal.askString(PROMPT);
			final String cmd;
			final String[] tokens;

			if (input == null) {
				// This error is weird and might indicate that some testing program has a bug
				// it means that the input was NOT terminated by \n or \r\n, but canceled
				// see http://docs.oracle.com/javase/1.3/docs/api/java/io/BufferedReader.html#readLine()
				error("The input stream was cancelled.");
				tokens = "quit".split("\\s+");
				cmd = "quit";
			} else {
				tokens = input.trim().split("\\s+");
				cmd = tokens[0];
			}

			if (CMD_NEW_GAME.equals(cmd)) {
				othello = newGameCommand(tokens, othello);
			} else if (CMD_MOVE.equals(cmd)) {
				moveCommand(tokens, othello);
			} else if (CMD_PRINT.equals(cmd)) {
				printCommand(tokens, othello);
			} else if (CMD_ABORT.equals(cmd)) {
				abortCommand(tokens, othello);
			} else if (CMD_HOLE.equals(cmd)) {
				holeCommand(tokens, othello);
			} else if (CMD_POSSIBLE_MOVES.equals(cmd)) {
				possibleMovesCommand(tokens, othello);
			} else if (CMD_QUIT.equals(cmd)) {
				quit = true;
			} else {
				error("Unknown command: '" + cmd + "'");
			}
		}
	}

	/**
	 * Prints an error message.
	 *
	 * @param msg error message to print
	 */
	private static void error(String msg) {
		println("Error! " + msg);
	}

	private static void println(String s) {
		System.out.println(s);
	}

}