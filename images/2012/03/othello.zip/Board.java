/**
 * The class {@code Board} represents the board with all pieces and holes.
 * @author Martin Thoma
 */
public class Board {
	/** error message: invalid character in situation string */
	public static final String ERR_INVALID_SITUATION_CHAR = "The situation parameter "
		+ "does only allow #,-,B,W and ,.";
	
	/** error message: invalid board size */
	public static final String ERR_INVALID_BOARD_SIZE = "No proper width or height.";
	
	/** minimum width of an Othello-Game board */
	public static final int MIN_WIDTH = 2;
	
	/** minimum width of an Othello-Game board */
	public static final int MAX_WIDTH = 26;
	
	/** minimum width of an Othello-Game board */
	public static final int MIN_HEIGHT = 2;
	
	/** minimum width of an Othello-Game board */
	public static final int MAX_HEIGHT = 98;
	
	/** the width of the board */
	public final int width;
	
	/** the height of the board */
	public final int height;
	
	/** the board with all pieces */
	private Field[][] board;

	/**
	 * Constructor for a board object.
	 * @param width the width of the board
	 * @param height the height of the board
	 */
	public Board(int width, int height) {
		this.width = width;
		this.height = height;
		
		if (!checkBoardSize(width, height)) {
			throw new IllegalArgumentException(ERR_INVALID_BOARD_SIZE);
		}
		
		this.board = new Field[width][height];
		
		// set the initial pieces on the board
		int x = width / 2;
		int y = height / 2;
		
		board[x - 1][y - 1] = Field.WHITE;
		board[x][y - 1] = Field.BLACK;
		board[x - 1][y] = Field.BLACK;
		board[x][y] = Field.WHITE;
	}
	
	/**
	 * Constructor for a board object.
	 * @param width the width of the board
	 * @param height the height of the board
	 * @param situation the situation of the new board
	 */
	public Board(int width, int height, String situation) {
		this.width = width;
		this.height = height;
		
		if (!checkBoardSize(width, height)) {
			throw new IllegalArgumentException(ERR_INVALID_BOARD_SIZE);
		}
		
		// Check if the situation string array is formatted correctly:
		if (!isSituationStringValid(width, height, situation)) {
			throw new IllegalArgumentException("The situation string isn't valid.");
		}
		
		this.board = new Field[width][height];
		
		int x;
		int y = 0;
		
		String[] aSituation = situation.split(",");
		
		for (String row : aSituation) {
			for (x = 0; x < width; x++) {
				char currentChar = row.charAt(x);
				if (currentChar == 'W') {
					set(x, y, Field.WHITE);
					//nextPlayer();
				} else if (currentChar == 'B') {
					set(x, y, Field.BLACK);
					//nextPlayer();
				} else if (currentChar == '#') {
					set(x, y, Field.HOLE);
				} else if (currentChar == '-') {
					set(x, y, null);
				} else {
					throw new IllegalArgumentException(ERR_INVALID_SITUATION_CHAR);
				}
			}
			
			y++;
		}
	}
	
	/**
	 * Check if the board size is valid.
	 * @param width the width of the board
	 * @param height the height of the board
	 * @return {@code true} if the board size is valid, otherwise {@code false}
	 */
	public static boolean checkBoardSize(int width, int height) {
		if (width < MIN_WIDTH || width > MAX_WIDTH || height < MIN_HEIGHT || height > MAX_HEIGHT) {
			return false;
		} else if (width % 2 == 1 || height % 2 == 1) {
			return false;
		}
		
		return true;
	}
	
	/**
	 * Checks if the given situation string is valid.
	 * @param width the width of the board
	 * @param height the height of the board
	 * @param situation the situation string
	 * @return {@code true} if the string is valid for this board, otherwise {@code false}
	 */
	public static boolean isSituationStringValid(int width, int height, String situation) {
		if (situation.indexOf(",") == -1) {
			return false;
		} else if (!situation.matches("^[B,W\\-#]*$")) {
			// a character is in the string which should not be there
			return false;
		}
		
		String[] aSituation = situation.split(",");
		
		if (aSituation.length != height) {
			return false;
		}
		
		for (String line : aSituation) {
			if (line.length() != width) {
				return false;
			}
		}

		return true;
	}
	
	/**
	 * This method sets a piece or a hole on the board. It does NOT check if 
	 * this is a valid move.
	 * @param x The x-coordinate
	 * @param y The y-coordinate
	 * @param player The player who wants to set the piece
	 */
	public void set(int x, int y, Field player) {
		board[x][y] = player;
	}
	
	/**
	 * This method sets a piece or a hole on the board. It does NOT check if 
	 * this is a valid move.
	 * @param pos the position where you want to set the new piece
	 * @param player The player who wants to set the piece
	 */
	public void set(Position pos, Field player) {
		set(pos.x, pos.y, player);
	}
	
	/**
	 * Get the piece at the position (x|y).
	 * @param x the x-coordinate of the piece you want to get
	 * @param y the y-coordinate of the piece you want to get
	 * @return the piece or {@code null}
	 */
	public Field get(int x, int y) {
		return board[x][y];
	}
	
	/**
	 * Get the piece at the position.
	 * @param position the position of the piece you want to get
	 * @return the piece or {@code null}
	 */
	public Field get(Position position) {
		return board[position.x][position.y];
	}
	
	/**
	 * Checks if a position is on the board.
	 * @param pos the positon you want to check
	 * @return {@code true} if the position is on the board, otherwise {@code false}
	 */
	public boolean isPositionOnBoard(Position pos) {
		return (0 <= pos.x && pos.x < width && 0 <= pos.y && pos.y < height);
	}
	
	/**
	 * This method returns a nice representation of the board.
	 * @return the nice String representation of the object.
	 */
	public String niceRepresentation() {
		String row;
		String representation = "";
		for (int y = 0; y < height; y++) {
			row = "";
			for (int x = 0; x < width; x++) {
				if (get(x, y) == Field.WHITE) {
					row += "W";
				} else if (get(x, y) == Field.BLACK) {
					row += "B";
				} else if (get(x, y) == Field.HOLE) {
					row += "#";
				} else {
					row += "-";
				}
			}
			representation += row + "\n";
		}
		return representation.trim();
	}
	
	/**
	 * Returns the String representation of a board object.
	 * @return the String representation of a board object
	 */
	@Override
	public String toString() {
		String s = "Board [" + height + "x" + width + "] ";
		for (int x = 0; x < width; x++) {
			if (x > 0) {
				s += ',';	
			}
			
			for (int y = 0; y < height; y++) {
				if (board[x][y] == Field.BLACK) {
					s += 'B';
				} else if (board[x][y] == Field.WHITE) {
					s += 'W';
				} else if (board[x][y] == Field.HOLE) {
					s += '#';
				} else {
					s += '-';
				}
			}
		}
		return s;
	}
}