/**
 * The enum {@code Field} represents the fields situation on a board and the players of 
 * a game.
 * HOLE can't be a player!
 * @author Martin Thoma
 */
public enum Field {
	/** The white piece / player */
	WHITE {
		@Override
		public String toString() {
			return "white";
		}
	}, 
	/** The black piece / player */
	BLACK {
		@Override
		public String toString() {
			return "black";
		}
	}, 
	/** a hole in the board */
	HOLE;
}