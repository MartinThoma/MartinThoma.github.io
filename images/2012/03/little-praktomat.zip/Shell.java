import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * The class {@code Shell} implements a simple shell to test the functionalities of the
 * LittlePraktomat.
 * @author Martin Thoma
 *
 */
public class Shell {

	/** the prompt of this shell */
	private static final String PROMPT = "praktomat> ";

	/** command to terminate the shell */
	private static final String CMD_QUIT = "quit";

	/** command to create a new tutor */
	private static final String CMD_NEW_TUTOR = "tut";

	/** command to create a new student */
	private static final String CMD_NEW_STUDENT = "stud";

	/** command to create a new task */
	private static final String CMD_NEW_TASK = "task";

	/** command to list all students */
	private static final String CMD_LIST_STUDENTS = "list-students";

	/** command to submit the solution for task for a student */
	private static final String CMD_SUBMIT_TASK = "submit";

	/** command to create a review of a task solved by a student */
	private static final String CMD_REVIEW = "review";

	/** command to list all solutions */
	private static final String CMD_LIST_SOLUTIONS = "list-solutions";

	/** command to list all results ordered ascending by ID */
	private static final String CMD_SHOW_RESULTS = "results";

	/** command to show a summary of the results of a task */
	private static final String CMD_SUMMARY_TASK = "summary-task";

	/** command to show a summary of all tutors */
	private static final String CMD_SHOW_TUTORS = "summary-tutor";

	/** command to show a summary of all students */
	private static final String CMD_SUMMARY_STUDENTS = "summary-student";

	/** command to re-initialise the praktomat */
	private static final String CMD_RESET = "reset";

	/** error message for the wrong format of names */
	private static final String ERR_NAME_FORMAT = "People may only have names with small characters from a to z.";

	/** error message for the wrong format of the student number */
	private static final String ERR_STUD_NUMBER_FORMAT = "The format of the student number was wrong. It has to be "
		+ "five digits long and at least 10,000.";

	/** error message for the wrong format of the task id */
	private static final String ERR_TASK_ID_FORMAT = "The task id has to be an integer.";

	/**
	 * Private constructor. This is a Utility class that should not be
	 * instantiated.
	 */
	private Shell() {
	}

	// handle the command for creating a new tutor: "tut <name>"
	private static void newTutCommand(String[] tokens, LittlePraktomat praktomat) {
		if (tokens.length != 2) {
			error("The command is: tut <name>.");
		} else if (!tokens[1].matches(Person.REGEX_NAME)) {
			error(ERR_NAME_FORMAT);
		} else {
		    // Hier war in meiner Abgabe ein Fehler ...
		    /*
			Tutor tutor = new Tutor(tokens[1]);
			if (!praktomat.containsTutor(tutor)) {
				praktomat.addTutor(tutor);
			}*/
		    // Das wäre richtig gewesen
		    Tutor tutor = praktomat.getTutorByName(tokens[1]);
		    if (tutor == null) {
		        tutor = new Tutor(tokens[1]);
		        praktomat.addTutor(tutor);
		    }
			praktomat.setCurrentTutor(tutor);
		}
	}

	// handle the command for a new student: stud <name> <student number>
	private static void newStudentCommand(String[] tokens, LittlePraktomat praktomat) {
		if (tokens.length != 3) {
			error("The command is: stud <name> <student number>");
		} else if (praktomat.getCurrentTutor() == null) {
			error("You have to add a tutor first.");
		} else if (!tokens[2].matches(Student.REGEX_STUD_NUMBER)) {
			error(ERR_STUD_NUMBER_FORMAT);
		} else if (praktomat.getStudentByStudentNr(Integer.parseInt(tokens[2])) != null) {
			error("A student with id " + tokens[2] + " already exists.");
		} else if (!tokens[1].matches(Person.REGEX_NAME)) {
			error(ERR_NAME_FORMAT);
		} else {
			// At this point I can be sure that the command had the right length,
			// the new student number is really new and valid, a tutor exists and is selected and
			// the format of the students name is correct
			Student student = new Student(tokens[1],
					Integer.parseInt(tokens[2]),
					praktomat.getCurrentTutor());
			praktomat.addStudent(student);
		}
	}

	// handle the command for creating a new task: "task <text>"
	private static void newTaskCommand(String[] tokens, LittlePraktomat praktomat) {
		if (tokens.length == 2) {
			int id = praktomat.addTask(tokens[1]);
			println("task id(" + id + ")");
		} else {
			error("The command is: task <text>");
		}
	}

	// handle the command "review <taskid> <student number> <grade> <text>"
	private static void reviewCommand(String[] tokens, LittlePraktomat praktomat) {
		if (tokens.length != 5) {
			error("The command is: review <taskid> <student number> <grade> <text>");
		} else if (!tokens[1].matches("[0-9]*")) {
			error(ERR_TASK_ID_FORMAT);
		} else if (!tokens[2].matches("[0-9]*")) {
			error("The student number has to an integer.");
		} else if (!tokens[3].matches("[1-5]{1}")) {
			error("The grade has to be in 1..5.");
		} else if (!tokens[2].matches(Student.REGEX_STUD_NUMBER)) {
			error(ERR_STUD_NUMBER_FORMAT);
		} else {
			int taskId = Integer.parseInt(tokens[1]);
			int studentNr = Integer.parseInt(tokens[2]);
			int grade = Integer.parseInt(tokens[3]);
			String text = tokens[4];

			Student student = praktomat.getStudentByStudentNr(studentNr);
			if (student != null) {
				Tutor t = student.getTutor();
				if (t.review(taskId, student, grade, text)) {
					println(t.getName() + " reviewed " + student.toString()
							+ " with grade " + grade);
				} else {
					error("The students solution to this task doesn't exist!");
				}
			} else {
				error("The student number you've provided is not in LittlePraktomat.");
			}
		}
	}

	// handle the command for "summary-task"
	private static void summaryTaskCommand(String[] tokens, LittlePraktomat praktomat) {
		if (tokens.length == 1) {
			Map<Integer, Task> tasks = praktomat.getTasks();
			for (Map.Entry<Integer, Task> entry : tasks.entrySet()) {
				Task task = entry.getValue();
				println("task id(" + task.getId() + "): " + task.getText());
				println("submitted: " + praktomat.getSolutionsToTask(task.getId()).size());
				println("reviewed: " + praktomat.getReviewedSolutions(task.getId()));

				double average = task.averageGrade();
				if (average == -1) {
					println("average grade: -");
				} else {
					System.out.format("average grade: %.2f%n", average);
				}

				int[] d = praktomat.getDistribution(task.getId());
				System.out.format("distribution: %dx1, %dx2, %dx3, %dx4, %dx5%n", d[0], d[1], d[2], d[3], d[4]);
			}
		} else {
			error("The command is: summary-task");
		}
	}

	// handle the command for submitting a solution to a task:
	// "submit <taskid> <student number> <text>"
	private static void submitTaskCommand(String[] tokens, LittlePraktomat praktomat) {
		if (tokens.length != 4) {
			error("The command is: submit <taskid> <student number> <text>");
		} else if (!tokens[2].matches(Student.REGEX_STUD_NUMBER)) {
			error(ERR_STUD_NUMBER_FORMAT);
		} else if (!tokens[1].matches("[0-9]*")) {
			error("The format of the Task-ID was not valid");
		} else {
			Student student = praktomat.getStudentByStudentNr(Integer.parseInt(tokens[2]));
			int taskId = Integer.parseInt(tokens[1]);

			if (student == null) {
				error("No student with id " + tokens[2] + " in LittlePraktomat.");
			} else if (!praktomat.containsTask(taskId)) {
				error("No task with ID " + taskId + " does exist.");
			} else if (student.getSolution(taskId) != null) {
				error("Student " + student + " has already submitted a solution.");
			} else {
				Solution solution = new Solution(praktomat.getTasks().get(taskId), tokens[3], student);
				student.submitSolution(solution);
			}
		}
	}

	// handle the command a summary of all tutors: "summary-tutors"
	private static void summaryTutorsCommand(String[] tokens, LittlePraktomat praktomat) {
		if (tokens.length == 1) {
			Set<Tutor> tutors = praktomat.getTutors();
			for (Tutor tutor : tutors) {
				if (tutor.averageGrade() == -1) {
					System.out.format("%s: %d students, %d missing review(s), average grade -%n",
							tutor.getName(), tutor.getStudentCount(), tutor.getMissingReviewCount());
				} else {
					System.out.format("%s: %d students, %d missing review(s), average grade %.2f%n",
							tutor.getName(), tutor.getStudentCount(), tutor.getMissingReviewCount(),
							tutor.averageGrade());
				}

			}
		} else {
			error("The command is: summary-tutor");
		}
	}

	// handle the command for printing the results to all tasks: "results"
	private static void resultsCommand(String[] tokens, LittlePraktomat praktomat) {
		if (tokens.length == 1) {
			Map<Integer, Task> tasks = praktomat.getTasks();
			for (Map.Entry<Integer, Task> entry : tasks.entrySet()) {
				Task task = entry.getValue();
				List<Solution> solutions = praktomat.getSolutionsToTask(task.getId());
				println("task id(" + task.getId() + "): " + task.getText());
				for (Solution solution : solutions) {
					int studentNumber = solution.getAuthor().getStudentNumber();
					if (solution.getReview() != null) {
						int grade = solution.getReview().getGrade();
						println(studentNumber + ": " + grade);
					}
				}
			}
		} else {
			error("The command is: results");
		}
	}

	// handle the command for a summary for all students: "summary-student"
	private static void summaryStudentsCommand(String[] tokens, LittlePraktomat praktomat) {
		if (tokens.length == 1) {
			List<Student> students = praktomat.getStudentsByGrade();
			for (Student student : students) {
				if (student.averageGrade() == -1) {
					println(student + ": -");
				} else {
					System.out.format("%s: %.2f%n", student, student.averageGrade());
				}
			}
		} else {
			error("The command is: summary-student");
		}
	}

	// handle the command for creating a new task: "list-students"
	private static void listStudentsCommand(LittlePraktomat praktomat) {
		Set<Student> students = praktomat.getStudents();
		for (Student student : students) {
			println(student + ": " + student.getTutor().getName());
		}
	}

	// handle the command for printing a list of all students: "list-solutions <taskid>"
	private static void listSolutionsCommand(String[] tokens, LittlePraktomat praktomat) {
		if (tokens.length != 2) {
			error("The command is: list-solutions <taskid>");
		} else if (!tokens[1].matches("[0-9]*")) {
			error(ERR_TASK_ID_FORMAT);
		} else {
			List<Solution> solutions = praktomat.getSolutionsToTask(Integer.parseInt(tokens[1]));
			if (solutions != null) {
				for (Solution solution : solutions) {
					System.out.format("%s: %s%n", solution.getAuthor(), solution.getText());
				}
			} else {
				error("The task couldn't be found.");
			}
		}
	}

	/**
	 * realizes the shell
	 * @param args command line arguments - not used here!
	 */
	public static void main(String[] args) {

		boolean quit = false;
		LittlePraktomat praktomat = new LittlePraktomat();

		while (!quit) {

			String input = Terminal.askString(PROMPT);

			// the name of the command
			final String cmd;
			final String[] tokens;

			if (input == null) {
				// This error is weird and might indicate that some testing programm has a bug
				// it means that the input was NOT terminated by \n or \r\n, but canceled
				// see http://docs.oracle.com/javase/1.3/docs/api/java/io/BufferedReader.html#readLine()
				error("The input stream was cancelled.");
				tokens = "quit".split("\\s+");
				cmd = "quit";
			} else {
				tokens = input.trim().split("\\s+");
				cmd = tokens[0].toLowerCase();
			}

			if (CMD_NEW_TUTOR.equals(cmd)) {
				newTutCommand(tokens, praktomat);
			} else if (CMD_NEW_STUDENT.equals(cmd)) {
				newStudentCommand(tokens, praktomat);
			} else if (CMD_NEW_TASK.equals(cmd)) {
				newTaskCommand(tokens, praktomat);
			} else if (CMD_LIST_STUDENTS.equals(cmd)) {
				listStudentsCommand(praktomat);
			} else if (CMD_SUBMIT_TASK.equals(cmd)) {
				submitTaskCommand(tokens, praktomat);
			} else if (CMD_REVIEW.equals(cmd)) {
				reviewCommand(tokens, praktomat);
			} else if (CMD_LIST_SOLUTIONS.equals(cmd)) {
				listSolutionsCommand(tokens, praktomat);
			} else if (CMD_SHOW_RESULTS.equals(cmd)) {
				resultsCommand(tokens, praktomat);
			} else if (CMD_SUMMARY_TASK.equals(cmd)) {
				summaryTaskCommand(tokens, praktomat);
			} else if (CMD_SHOW_TUTORS.equals(cmd)) {
				summaryTutorsCommand(tokens, praktomat);
			} else if (CMD_SUMMARY_STUDENTS.equals(cmd)) {
				summaryStudentsCommand(tokens, praktomat);
			} else if (CMD_RESET.equals(cmd)) {
				if (tokens.length == 1) {
					praktomat = new LittlePraktomat();
				} else {
					error("The command is: reset");
				}
			} else if (CMD_QUIT.equals(cmd)) {
				quit = true;
			} else {
				error("Unknown command: '" + cmd + "'");
			}
		}
	}

	/**
	 * Prints an error message.
	 *
	 * @param msg error message to print
	 */
	private static void error(String msg) {
		println("Error! " + msg);
	}

	private static void println(String s) {
		System.out.println(s);
	}

}
