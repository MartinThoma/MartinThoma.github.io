import java.util.HashSet;
import java.util.Set;

/**
 * The class {@code Task} represents a task which has to be solved by students.
 * Every task has a unique task-ID.
 *
 * @author Martin Thoma
 */
public class Task implements AverageGrade {
	
	/** unique ID of the task */
	private int id;
	
	/** the actual task */
	private String text;
	
	/** all solutions which were uploaded to this task */
	private Set<Solution> solutions = new HashSet<Solution>();
	
	/**
	 * Constructs a new task.
	 * @param id the unique id of the task
	 * @param text the task
	 */
	public Task(int id, String text) {
		this.id   = id;
		this.text = text;
	}
	
	/**
	 * Add a solution.
	 * This method should be called by {@link Student#submitSolution(Solution)}.
	 * If packages would work, this should be protected.
	 * @param solution the solution
	 */
	public void addSolution(Solution solution) {
		solutions.add(solution);
	}
	
	/**
	 * Return the text of this task.
	 * @return the text of this task
	 */
	public String getText() {
		return text;
	}
	
	/**
	 * Return the unique id of this task.
	 * @return the unique task-id
	 */
	public int getId() {
		return id;
	}

	/**
	 * Return the solutions for this task.
	 * @return the solutions for this task
	 */
	public Set<Solution> getSolutions() {
		return solutions;
	}
	
	/**
	 * Calculate the average grade of this task by building the mean
	 * over all graded solutions to this task. Solution is rounded by 
	 * two decimal places.
	 * If no solution was submitted and graded, this method will 
	 * return -1.
	 * @return the average grade of solutions to this task, otherwise -1
	 */
	@Override
	public double averageGrade() {
		double sum = 0;
		int gradedSolutions = 0;
		for (Solution solution : solutions) {
			if (solution.getReview() != null) {
				sum += solution.getReview().getGrade();
				gradedSolutions++;
			}
		}
		
		double average = -1;
		if (gradedSolutions > 0) {
			average = sum / gradedSolutions;
		}
		return (double) Math.round(average * 100) / 100;
	}

	@Override
	public String toString() {
		return "Task [id=" + id + ", text=" + text + "]";
	}
}
