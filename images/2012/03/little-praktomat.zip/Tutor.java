import java.util.HashSet;
import java.util.Set;

/**
 * The class {@code Tutor} represents a tutor.
 * @author Martin Thoma
 */
public class Tutor extends Person implements AverageGrade, Comparable<Tutor> {
	
	/** the students of this tutor */
	private Set<Student> students = new HashSet<Student>();
	
	/** the solutions which need to be reviewed */
	private Set<Solution> missingReviews = new HashSet<Solution>();
	
	/** the reviews which have been done */
	private Set<Review> reviewsDone = new HashSet<Review>();
	
	/**
	 * Constructs a tutor with the given name.
	 * @param name name of the tutor
	 */
	public Tutor(String name) {
		super(name);
	}
	
	/**
	 * Add a student to the set of students this tutor has to teach.
	 * @param student the new student
	 */
	public void addStudent(Student student) {
		if (student == null) {
			throw new IllegalArgumentException();
		}
		
		students.add(student);
	}
	
	/**
	 * Return the number of students this tutor has.
	 * @return the number of students of this tutor
	 */
	public int getStudentCount() {
		return students.size();
	}
	
	/**
	 * Create a review.
	 * @param taskId the task whose solution was reviewed
	 * @param student the student who wrote the solution.
	 * @param grade the grade this student gets. It has to be in 1..5
	 * @param text the explanation why he gets this grade
	 * @return {@code true} if the review could be created, otherwise {@code false}
	 */
	public boolean review(int taskId, Student student, int grade, String text) {
		Solution solution = student.getSolution(taskId);
		boolean wasSuccessful = false;
		
		if (solution != null && grade >= 1 && grade <= 5) {
			Review review = new Review(grade, text, solution);
			solution.setReview(review);
			reviewsDone.add(review);
			missingReviews.remove(solution);
			wasSuccessful = true;
		}
		return wasSuccessful;
	}
	
	/**
	 * Add a missing review.
	 * This method should be called by {@link Student#submitSolution(Solution)}.
	 * If packages would work, this should be protected.
	 * @param solution add the solution which needs to be reviewed
	 */
	public void addMissingReview(Solution solution) {
		missingReviews.add(solution);
	}
	
	/**
	 * Return the number of missing reviews of this tutor.
	 * @return the number of missing reviews of this tutor
	 */
	public int getMissingReviewCount() {
		return missingReviews.size();
	}
	
	/**
	 * Get the average grade this tutor gives in his reviews rounded by
	 * two decimal places.
	 * If no reviews have been done yet, return -1.
	 * @return the average grade
	 */
	@Override
	public double averageGrade() {
		double gradeSum = 0;
		double averageGrade;
		for (Review review : reviewsDone) {
			gradeSum += review.getGrade();
		}
		if (reviewsDone.size() > 0) {
			averageGrade = gradeSum / reviewsDone.size();
			averageGrade = (double) Math.round(averageGrade * 100) / 100;
		} else {
			averageGrade = -1;
		}

		return averageGrade;
	}

	/**
	 * This method compares the current student with another student based on their student number.
	 * @param o the tutor to be compared
	 * @return a negative integer, zero, or a positive integer as the the specified name of the tutor 
	 * is greater than, equal to, or less than this String, ignoring case considerations
	 */
	@Override
	public int compareTo(Tutor o) {
		return this.getName().compareTo(o.getName());
	}
}
