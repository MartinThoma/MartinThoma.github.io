/**
 * The class {@code Person} models a person in the LittlePraktomat. A person has a name.
 * @author Martin Thoma
 */

public class Person {
	
	/** name of the person */
	private String name;
	
	/** regular expression which matches correct names of persons */
	public static final String REGEX_NAME = "[a-z]*";

	/**
	 * Constructs a new person with the given name.
	 * @param name name of the person
	 */
	public Person(String name) {
		if (name == null || !name.matches("[a-z]*")) {
			throw new IllegalArgumentException();
		}

		this.name = name;
	}
	
	/**
	 * Returns this person's name.
	 * @return this person's name
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * Returns a string representation of this person.
	 * @return a string representation of this person
	 */
	@Override
	public String toString() {
		return name;
	}
}
