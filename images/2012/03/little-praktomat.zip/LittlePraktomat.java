import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

/**
 * The class {@code LittlePraktomat} represents the LittlePraktomat itself. It stores the tutors and
 * the students.
 *
 * The Java Doc can be found here:
 * <a href="http://www.martin-thoma.de/programmieren-123dasf43fi4l2nS4/">
 * martin-thoma.de/programmieren-123dasf43fi4l2nS4</a>
 *
 * I've also created a
 * <a href="http://www.martin-thoma.de/programmieren-123dasf43fi4l2nS4/class-diagram/class-diagram.pdf">
 * class diagram</a>
 * for a better overview.
 *
 * A python script for testing if the tests of Tests.txt get passed by this LittlePraktomat can
 * be found <a href="http://martin-thoma.com/abschlussaufgaben-programmieren/">here</a>.
 *
 * @author Martin Thoma
 *
 */

public class LittlePraktomat implements AverageGrade {
	/** the tutors in the LittlePraktomat */
	private final Set<Tutor> tutors = new TreeSet<Tutor>();

	/** the tutor which is selected at the moment */
	private Tutor currentTutor;

	/** the students in the LittlePraktomat */
	private final Set<Student> students = new TreeSet<Student>();

	/** the Tasks */
	private final Map<Integer, Task> tasks = new HashMap<Integer, Task>();

	/** the id of the next Task */
	private int nextTaskId = 1;

	/**
	 * Add a new tutor to this LittlePraktomat.
	 * @param tutor The tutor you want to add.
	 */
	public void addTutor(Tutor tutor) {
		if (tutor == null) {
			throw new IllegalArgumentException();
		}

		tutors.add(tutor);
	}

	/**
	 * Add a new student to this LittlePraktomat.
	 * @param student the student you want to add
	 * @throws IllegalStateException If a student
	 * with the same student number is already in this LittlePraktomat
	 */
	public void addStudent(Student student) {
		if (student == null) {
			throw new IllegalArgumentException();
		} else if (getStudentByStudentNr(student.getStudentNumber()) != null) {
			// a student with this student number is already in LittlePraktomat
			throw new IllegalStateException();
		} else {
			students.add(student);
			currentTutor.addStudent(student);
		}
	}

	/**
	 * Add a new task to this LittlePraktomat and return the ID of this task.
	 * @param text the text of the task you want to add.
	 * @return the id of the task in LittlePraktomat.
	 */
	public int addTask(String text) {
		Task task = new Task(nextTaskId, text);
		tasks.put(nextTaskId, task);
		nextTaskId++;
		return (nextTaskId - 1);
	}

	/**
	 * Returns whether the given tutor is a member of this LittlePraktomat.
	 * @param tutor the tutor to be checked.
	 * @return {@code true} if the given tutor is a member of this LittlePraktomat,
	 * {@code false} otherwise.
	 */
	public boolean containsTutor(Tutor tutor) {
		if (tutor == null) {
			throw new IllegalArgumentException();
		}

		return tutors.contains(tutor);
	}

	/**
	 * Returns whether a task with the given taskId is in this LittlePraktomat.
	 * @param taskId the ID of the task to be checked.
	 * @return {@code true} if a task with the given taskId is in this LittlePraktomat,
	 * {@code false} otherwise.
	 */
	public boolean containsTask(int taskId) {
		return tasks.containsKey(taskId);
	}

	/**
	 * Get the currently selected tutor.
	 * @return the currently selected tutor.
	 */
	public Tutor getCurrentTutor() {
		return currentTutor;
	}

	/**
	 * Set the currently selected tutor to the the given tutor.
	 * @param tutor the new current tutor.
	 */
	public void setCurrentTutor(Tutor tutor) {
		if (!tutors.contains(tutor) || tutor == null) {
			throw new IllegalArgumentException();
		}

		currentTutor = tutor;
	}

	/**
	 * Get all tutors that are currently in this LittlePraktomat.
	 * @return the tutors in this LittlePraktomat
	 */
	public Set<Tutor> getTutors() {
		return tutors;
	}

	/**
	 * Get all students that are currently in this LittlePraktomat.
	 * @return the students in this LittlePraktomat
	 */
	public Set<Student> getStudents() {
		return students;
	}

	/**
	 * Searches the student by his student number.
	 * If he is not found, null is returned.
	 *
	 * @param studentNumber The student number
	 * @return the Student or {@code null}
	 */
	public Student getStudentByStudentNr(int studentNumber) {
		Student searchedStudent = null;

		for (Student student : students) {
			if (student.getStudentNumber() == studentNumber) {
				searchedStudent = student;
				break;
			}
		}

		return searchedStudent;
	}

	/**
	 * Return all tasks of this LittlePraktomat.
	 * @return all tasks that are currently in this LittlePraktomat
	 */
	public Map<Integer, Task> getTasks() {
		return tasks;
	}

	/**
	 * Get all solutions of one task sorted by student number. If
	 * the task couldn't be found this method returns null.
	 * @param taskId the Id of the task
	 * @return the sorted list of solutions if solutions to this task exist,
	 * {@code null} otherwise.
	 */
	public List<Solution> getSolutionsToTask(int taskId) {
		// convert the HashSet to a List
		List<Solution> tasksSolutions = null;
		if (tasks.get(taskId) != null) {
			tasksSolutions = new LinkedList<Solution>();
			for (Solution solution : tasks.get(taskId).getSolutions()) {
				tasksSolutions.add(solution);
			}

			Comparator<Solution> comparator = new StudentSolutionComperator();
			java.util.Collections.sort(tasksSolutions, comparator);
		}

		return tasksSolutions;
	}

	/* This class is needed to sort the solutions submitted by students.*/
	private class StudentSolutionComperator implements Comparator<Solution> {
		public int compare(Solution a, Solution b) {
			if (a.getAuthor().getStudentNumber() < b.getAuthor().getStudentNumber()) {
				return -1;
			} else if (a.getAuthor().getStudentNumber() > b.getAuthor().getStudentNumber()) {
				return 1;
			} else {
				return 0;
			}
		}
	}

	/**
	 * I forgot to implement this ...
	 * @param name the name of the tutor
	 * @return the tutor
	 */
	public Tutor getTutorByName(String name) {
	    for (Tutor tutor : tutors) {
	        if (tutor.getName().equals(name)) {
	            return tutor;
	        }
	    }
	    return null;
	}

	/**
	 * Get the number of solutions that are already reviewed to a given task.
	 * @param taskId the task given by its id
	 * @return the number of solutions that are already reviewed
	 */
	public int getReviewedSolutions(int taskId) {
		List<Solution> solutions = getSolutionsToTask(taskId);
		int reviewCount = 0;
		for (Solution solution : solutions) {
			if (solution.getReview() != null) {
				reviewCount++;
			}
		}
		return reviewCount;
	}

	/**
	 * Get the distribution of grades.
	 * @param taskId the task given by its id
	 * @return the grade-distribution. The index is equal to grade -1!
	 */
	public int[] getDistribution(int taskId) {
		int[] distribution = new int[5];
		List<Solution> solutions = getSolutionsToTask(taskId);
		for (Solution solution : solutions) {
			if (solution.getReview() != null) {
				distribution[solution.getReview().getGrade() - 1]++;
			}
		}
		return distribution;
	}

	/**
	 * Get a list of all students sorted by grade.
	 * @return the sorted list of all students.
	 */
	public List<Student> getStudentsByGrade() {
		List<Student> studentsList = new LinkedList<Student>();
		for (Student student : students) {
			studentsList.add(student);
		}

		Comparator<Student> comparator = new StudentGradeComperator();
		java.util.Collections.sort(studentsList, comparator);

		return studentsList;
	}

	/* This class is needed to sort the students by their average grade. */
	private class StudentGradeComperator implements Comparator<Student> {
		public int compare(Student a, Student b) {
			if (a.averageGrade() == b.averageGrade()) {
				return 0;
			} else if (a.averageGrade() == -1) {
				return 1;
			} else if (b.averageGrade() == -1) {
				return -1;
			} else if (a.averageGrade() > b.averageGrade()) {
				return 1;
			} else {
				return -1;
			}
		}
	}

	@Override
	public double averageGrade() {
		double averageGrade = 0;
		double avgTmp = 0;
		int counter = 0;

		for (Tutor tutor : tutors) {
			avgTmp = tutor.averageGrade();
			if (avgTmp != -1) {
				averageGrade += avgTmp;
				counter++;
			}
		}

		if (counter == 0) {
			averageGrade = -1;
		} else {
			averageGrade = averageGrade / counter;
		}

		return averageGrade;
	}
}


