/**
 * The class {@code Review} represents a review and correlated metadata.
 * @author Martin Thoma
 */
public class Review {
	/** the grade the student got for his solution
	 *	[1, 2, 3, 4, 5], 1 is the best, 5 the worst grade 
	 *  If the system universities grade their students should eventually
	 *  change, this can be replaced by a class.
	 */
	private final int grade;
	
	/** the explanation for the grade */
	private final String text;
	
	/** the solution which was graded */
	private final Solution solution;
	
	/**
	 * Constructs a new review and automatically connects
	 * the solution with the review.
	 * @param grade the grade
	 * @param text the explanation of the grade
	 * @param solution the solution that was graded
	 */
	public Review(int grade, String text, Solution solution) {
		this.grade = grade;
		this.text = text;
		this.solution = solution;
		
		solution.setReview(this);
	}
	
	/**
	 * Return the grade of this review.
	 * @return the grade of this review
	 */
	public int getGrade() {
		return grade;
	}

	/**
	 * Return the text of the review.
	 * @return the text of the review
	 */
	public String getText() {
		return text;
	}

	/**
	 * Return the solution this review belongs to.
	 * @return the solution this review belongs to
	 */
	public Solution getSolution() {
		return solution;
	}

	/**
	 * Return a String representation of a review.
	 * @return a String representation of a review
	 */
	@Override
	public String toString() {
		return "Review [grade=" + grade + ", taskID=" + solution.getTask().getId() 
			+ ", student=" + solution.getAuthor().getStudentNumber() 
			+ ", text=" + text + "]";
	}
}