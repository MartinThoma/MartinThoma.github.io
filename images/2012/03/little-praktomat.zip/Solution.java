/**
 * The class {@code Solution} represents a solution of a task and correlated metadata.
 * Once a solution was created, the author of the solution,
 * the task the solution belongs to and the solution itself
 * can't be changed.
 * @author Martin Thoma
 *
 */
public class Solution {
	
	/** the student who wrote the solution */
	private final Student author;

	/** the task to which this solution belongs to */
	private final Task task;
	
	/** the solution */
	private final String text;
	
	/** the review - initially null */
	private Review review;
	
	/**
	 * Constructs a new solution to a task.
	 * @param task the task to which this solution belongs to
	 * @param text the solution itself
	 * @param author the student who wrote the solution
	 */
	public Solution(Task task, String text, Student author) {
		this.task = task;
		this.text = text;
		this.author = author;
	}
	
	/**
	 * Return the text of this solution.
	 * @return the text of this solution
	 */
	public String getText() {
		return text;
	}
	
	/**
	 * Return the task that belongs to this solution.
	 * @return the task that belongs to this solution
	 */
	public Task getTask() {
		return task;
	}
	
	/**
	 * Return the student who wrote the solution.
	 * @return the student who wrote the solution
	 */
	public Student getAuthor() {
		return author;
	}
	
	/**
	 * Return the review that belongs to this solution if it exists.
	 * @return the review that belongs to this solution if it exists, otherwise {@code null}
	 */
	public Review getReview() {
		return review;
	}
	
	/**
	 * Set the review for this solution.
	 * @param review the review for this solution
	 */
	public void setReview(Review review) {
		this.review = review;
	}
	
	@Override
	public String toString() {
		return "Solution ["
		+ "author student number=" + author.getStudentNumber()
		+ "taskId=" + task.getId()
		+ ", text=" + text + "]";
	}
}
