import java.util.HashMap;
import java.util.Map;

/**
 * The class {@code Student} represents a student.
 * @author Martin Thoma
 */
public class Student extends Person implements Comparable<Student>, AverageGrade {
	
	/** The student number */
	// I thought about creating a seperated class for the student number.
	// I rejected this idea, because it is very unlikely that the format of the
	// student number will change and only students need a student number.
	private int studentNumber;
	
	/** regular expression which matches correct student numbers */
	public static final String REGEX_STUD_NUMBER = "[1-9]{1}[0-9]{4}";
	
	/** The tutor of this student */
	// It would be enough to save this information in the LittlePraktomat,
	// but it is only one reference per student more. So if 2.000 students
	// use the praktomat, it is on a 32-bit system less than 8 kB more to store.
	// That should be okay, especially as the logic of the program gets much
	// easier to understand and much less calculations are needed to get this
	// information.
	private Tutor myTutor;
	
	/** All solutions submitted by the student */
	private Map<Integer, Solution> solutions = new HashMap<Integer, Solution>();

	/**
	 * Constructs a new student with the given name.
	 * @param name the name of the student
	 * @param studentNumber the student number. The student number has to be 
	 * in 10000..99999.
	 * @param tutor the name of the tutor of this student
	 * @throws IllegalArgumentException If the student number is not in 10000..99999
	 */
	public Student(String name, int studentNumber, Tutor tutor) {
		super(name);
		
		if (studentNumber < 10000 || 99999 < studentNumber) {
			throw new IllegalArgumentException();
		}
		
		this.studentNumber = studentNumber;
		myTutor = tutor;
	}
	
	/**
	 * Return the student number of this student.
	 * @return the student number of this student
	 */
	public int getStudentNumber() {
		return studentNumber;
	}
	
	/**
	 * Return the tutor of this student.
	 * @return the tutor of this student
	 */
	public Tutor getTutor() {
		return myTutor;
	}
	
	/**
	 * Return the solution of the task with taskId if it exists or {@code null}.
	 * @param taskId the task you want to get the solution for
	 * @return the solution for taskId if it exists, otherwise {@code null}
	 */
	public Solution getSolution(int taskId) {
		return solutions.get(taskId);
	}
	
	/**
	 * Submit a solution to a task for this student.
	 * @param solution the solution the student wants to submit
	 * @throws IllegalStateException If the student already submitted a solution
	 */
	public void submitSolution(Solution solution) {
		
		int taskId = solution.getTask().getId();
		
		if (solutions.get(taskId) != null) {
			throw new IllegalStateException();
		}
		
		solutions.put(taskId, solution);
		solution.getTask().addSolution(solution);
		myTutor.addMissingReview(solution);
	}
	
	/**
	 * Return a String-representation of a student.
	 * @return A String representation of a student.
	 */
	@Override
	public String toString() {
		return "(" + studentNumber + "," + this.getName() + ")";
	}
	
	/**
	 * This method compares the current student with another 
	 * student based on their student number.
	 * @param otherStudent the other student
	 * @return -1 if the other one has a lower student number, 0 if 
	 * both are the same and +1 if the other ones number is higher
	 */
	public int compareTo(Student otherStudent) {
		if (this.studentNumber == otherStudent.studentNumber) {
			return 0;
		} else if (this.studentNumber > otherStudent.studentNumber) {
			return 1;
		} else {
			return -1;
		}
	}

	/**
	 * Calculate and return the average grade of this student.
	 * @return the average Grade of this student. If no average can be calculated, return -1.
	 */
	public double averageGrade() {
		double summe = 0;
		int gradedSolutions = 0;
		double average = -1;
		for (Map.Entry<Integer, Solution> entry : solutions.entrySet()) {
			Solution solution = entry.getValue();
			if (solution.getReview() != null) {
				summe += solution.getReview().getGrade();
				gradedSolutions++;
			}

		}
		
		if (gradedSolutions > 0) {
			average = (double) Math.round((summe / gradedSolutions) * 100) / 100;
		}
		
		return average;
	}

}
