<?

for($i=0;$i<10;$i++){
    echo "In loop: $i<br/>";
    //$i++;
}
echo "Out of loop: $i<br/>";

$array = array(0, 1, 2, 3, 4);

foreach ($array as $key=>$value) {
    echo "Foreach: $value<br/>";
}

?>
