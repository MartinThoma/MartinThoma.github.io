#include <iostream>

using namespace std;

int main() {
    for (int i=0; i < 10; i++) {
        cout<<"In loop: "<<i<<"\n";
        //i++;
    }
    
    // std::cout<<"Out of loop: "<<i<<"\n";
    // loop.cpp:9: error: name lookup of ‘i’ changed for ISO ‘for’ scoping
/*
    int array[5];
    array[0] = 0;
    array[1] = 1;
    array[2] = 2;
    array[3] = 3;
    array[4] = 4;
    foreach (int i in array)
    {
        std::cout<<"Foreach: "<<i<<"\n";
    }*/
}
