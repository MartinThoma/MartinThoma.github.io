public class loop  {
    public static void main (String[] args) {

        for (int i = 0; i < 10; i++) {
            System.out.println("In loop: " + i);
            //i++;
        }
        
        // System.out.println("Out of loop: " + i);
        // loop.java:9: cannot find symbol

        int[] array = new int[5];
        array[0] = 0;
        array[1] = 1;
        array[2] = 2;
        array[3] = 3;
        array[4] = 4;

        for (int item: array) {
            System.out.println("Foreach: " + item);
        }

    }
}
