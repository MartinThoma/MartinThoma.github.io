for(var i = 0; i < 10; i++) {
    document.write('In loop: ' + i + '<br/>');
    //i += 1;
}

document.write('Out of loop: ' + i + '<br/>');

var array = new Array(0, 1, 2, 3, 4);

for (var value in array) {
    document.write('Foreach: ' + value + '<br/>' );
}
