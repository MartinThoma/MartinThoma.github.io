#include <stdio.h>

int main (void) {

    for (int i = 0; i < 10; i++) {
        printf("In loop: %i\n", i);
        //i++;
    }

    // loop.c:10: error: ‘i’ undeclared (first use in this function)
    // printf("Out of loop: %i\n", i);
}
