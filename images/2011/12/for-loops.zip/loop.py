#!/usr/bin/python
# -*- coding: utf-8 -*-

for i in xrange(0, 10):
	print("In loop: %i" % i)
    #i += 1

print("Out of loop: %i" % i)

array = [0, 1, 2, 3, 4]

for value in array:
    print "Foreach: %i" % value
