package edu.kit.filesystem;

public class File extends Node {
    public File(String name, String description) {
        this.setName(name);
        this.setDescription(description);
    }
}