package edu.kit.filesystem;

import java.util.ArrayList;

public class Directory extends Node implements NodeContainer {
    private final ArrayList<Node> nodes = new ArrayList<Node>();

    public Directory(String name, String description) {
        this.setName(name);
        this.setDescription(description);
    }

    public void addNode(Node n) {
        nodes.add(n);
    }

    @SuppressWarnings("unchecked")
    public <T> ArrayList<T> get(Class<T> clazz) {
        ArrayList<T> allElements = new ArrayList<T>();
        for(Node o : nodes) {
            if (o.getClass() == clazz) {
                allElements.add((T) o);
            }
        }
        return allElements;
    }
}