package edu.kit.filesystem;

import java.util.ArrayList;

public interface NodeContainer {
    public <T> ArrayList<T> get(Class<T> clazz);
    public void addNode(Node n);
}