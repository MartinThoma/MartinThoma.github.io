package edu.kit.filesystem;

import java.util.ArrayList;
import java.util.Vector;

public class Computer {
    public String computerName;
    public Vector<HDD> hdds = new Vector<HDD>();

    public Computer(String companyName, HDD gf) {
        this.computerName = companyName;
        this.hdds.add(gf);
    }

    private void addDrive(HDD drive) {
        hdds.add(drive);
    }

    public void printContent() {
        for (HDD hdd : hdds) {
            System.out.println("| HDD: " + hdd.getName() + " ("
                    + hdd.getDescription() + ")");

            for (Directory dir : hdd.get(Directory.class)) {
                printContent(dir, "");
            }

            for (ZipArchiv zip : hdd.get(ZipArchiv.class)) {
                printContent(zip, "");
            }

            for (File f : hdd.get(File.class)) {
                printContent(f, "|-");
            }
        }
    }

    private void printContent(Node d, String ident) {
        System.out.println("|-" + ident + " " + d.getName());

        ArrayList<Class<? extends Node>> list = new ArrayList<Class<? extends Node>>();
        list.add(Directory.class);
        list.add(ZipArchiv.class);
        list.add(File.class);

        if (d instanceof NodeContainer) {
            NodeContainer e = (NodeContainer) d;
            for (Class<? extends Node> T : list) {
                ArrayList<? extends Node> tmp = e.get(T);
                for (Node n : tmp) {
                    printContent(n, ident + "-");
                }
            }
        }
    }

    public static void main(String[] args) {
        // Create the computer
        HDD platte1 = new HDD("C", "Main disk");
        Computer f = new Computer("MyMainComputer", platte1);

        // we need a backup
        HDD platte2 = new HDD("D", "Backup disk");
        f.addDrive(platte2);

        // create main directories
        Directory v1 = new Directory("temp", "temporary files");
        platte1.addNode(v1);
        v1.addNode(new Directory("asdf", "jklö"));
        Directory v2 = new Directory("Pictures", "Holiday pictures");
        platte1.addNode(v2);

        // Gib den Verzeichnissen ein paar Inhalte
        // Ein paar Archive im Temp
        ZipArchiv zip1 = new ZipArchiv("fp-update.zip",
                "Flashplayer Update");
        v1.addNode(zip1);
        ZipArchiv zip2 = new ZipArchiv("swt1-folien.zip",
                "PDFs of SWT1");
        v1.addNode(zip2);

        // pictures
        ZipArchiv barcelona = new ZipArchiv("2010-Barcelona.zip",
                "Holiday Barcelona 2010");
        v2.addNode(barcelona);
        ZipArchiv mallorca = new ZipArchiv("2011-Mallorca.zip",
                "Sonne satt");
        v2.addNode(mallorca);
        v2.addNode(new File("ipdlogo.png", "IPD"));

        // add some files to archives
        ZipArchiv b1 = new ZipArchiv("BarcelonaBeach.zip",
                "Strandbilder");
        barcelona.addNode(b1);
        b1.addNode(new File("s1.jpg", "Strand"));
        b1.addNode(new File("s2.jpg", "Mehr Strand"));
        b1.addNode(new File("s3.jpg", "Strand und Meer"));
        b1.addNode(new File("s4.jpg", "Noch mehr Strand"));

        File b2 = new File("Picasso.jpg", "Museum");
        barcelona.addNode(b2);

        File b3 = new File("SagradaFamilia.jpg", "Kirche");
        barcelona.addNode(b3);

        File b4 = new File("CampNou.jpg", "Fußball");
        barcelona.addNode(b4);

        File m1 = new File("Strand.jpg", "Strand");
        mallorca.addNode(m1);

        f.printContent();
    }
}