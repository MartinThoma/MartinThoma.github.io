#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys

def is_square(integer):
    if int(integer ** 0.5) ** 2 == integer: 
        return True
    else:
        return False

for x in xrange(3,1000):
	if (x % 10 == 0): print x
	for y in xrange(2, x):
		for z in xrange(1, y):
			if (x > y and y > z):
				if (is_square(x + y)
					and is_square(x - y)
					and is_square(x + z)
					and is_square(x - z)
					and is_square(y + z)
					and is_square(y - z)):
						print ("%i - %i - %i" % (x, y, z))
						sys.exit()
